﻿using System;
using System.ComponentModel;

namespace OnalloProjekt.Models
{
    public class szamol : INotifyPropertyChanged
    {
        private string _name;
        private double _sugar;

        public szamol()
        {
            _name = string.Empty;
            _sugar = 0;
        }
        public string Name
        {
           get => _name; 
            set =>  _name = value;
        }
        public double Sugar
        {
            get => _sugar;
            set => _sugar = value;
        }

        public double Atmero
        {
            get
            {
                return  2 * Sugar;

            }
        }
        public double Pi
        {
            get
            { return 3.14; }
        }
     
        public double Kerulet
        {
            get
            {
                return 2 * Pi * Sugar;
            }
        }

        public double Terulet
        {
            get
            {
                return Pi * Math.Pow(Sugar, 2);
            }
        }

        public double Felszin
        {
            get
            {
                return 4 * Math.Pow(Sugar, 2) * Pi;
            }
        }

        public  double Térfogat
        {
            get
            {
                return (4 * Math.Pow(Sugar, 3) * Pi) / 3;
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
    }

}
