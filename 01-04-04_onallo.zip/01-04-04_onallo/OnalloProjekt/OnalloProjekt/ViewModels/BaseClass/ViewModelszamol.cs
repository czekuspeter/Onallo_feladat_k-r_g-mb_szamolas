﻿using Accessibility;
using OnalloProjekt.Models;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ViewModels.BaseClass;


namespace OnalloProjekt.ViewModels.BaseClass
{
    public class ViewModelszamol : ViewModelBase
    {
        private szamol _szam;

        public ViewModelszamol()
        {
            _szam = new szamol();
            CloseCommand = new RelayCommand(execute => CloseWindow());
            CalculationCommand = new RelayCommand(execute => Calculation());
        }
        public RelayCommand CloseCommand { get; private set; }
        public RelayCommand CalculationCommand { get; private set; }
        public string Name
        {
            get
            {
                return _szam.Name;
            }

            set
            {
                _szam.Name = value;
            }
        }
        public string Sugar
        {
            get
            {
                return _szam.Sugar.ToString();
            }
            set
            {
                try
                {
                    double sugar = Convert.ToDouble(value);
                    _szam.Sugar = sugar;
                }
                catch (Exception e)
                {
                }
            }
        }

        public string Atmero
        {
            get
            {
                double roundedatmero = _szam.Atmero;
                return "Atmero: " + roundedatmero;
            }
        }

        public string Kerulet
        {
            get
            {
                double roundedkerulet = _szam.Kerulet;
                return "Kerület számítás: " + roundedkerulet;
            }
        }
            public string Terulet
        {
            get
            {
                double roundedterulet = _szam.Terulet;
                return "Terület számítás" + roundedterulet;
            }
        }

        public string Felszin
        {
            get
            {
                double roundedfelszin = _szam.Felszin;
                return "Felszín számítás" + roundedfelszin;
            }
        }

        public string Térfogat
        {
            get
            {
                double roundedterfogat = _szam.Térfogat;
                return "Térfogat számítás" + roundedterfogat;
           }
        }
        private void CloseWindow()
        {
            Application.Current.Windows[0].Close();
        }

        private void Calculation()
        {
            OnPropertyChanged(nameof(Atmero));
            OnPropertyChanged(nameof(Kerulet));
            OnPropertyChanged(nameof(Terulet));
            OnPropertyChanged(nameof(Felszin));
            OnPropertyChanged(nameof(Térfogat));
            
        }

        
    }

 }


